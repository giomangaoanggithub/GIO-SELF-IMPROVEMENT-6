<?php

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "essay_speed_checker_db";

?>